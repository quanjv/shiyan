/**
	* 完成课时
	* @example finishLesson(1);
	* @param {Number} lesson 课程
*/
function finishLesson(lesson) {
	
	alert("恭喜，你已经完成HBuilder入门课程。你可以用其它开发工具试试写这几十行代码，至少比HBuilder慢5倍！更重要的是，你很难找到这么爽的编码体验。");
}